# Changelog

| Chart version | App version | Change description |
| :------------ | :---------- | :----------------- |
| 0.1.0 | 8.0.29 | Initial version of chart |
| 0.1.1 | 8.0.30 | Upgraded MySQL to 8.0.30 |
| 0.1.2 | 8.0.30 | Implemented support for custom inline init scripts |
| 0.1.3 | 8.0.30 | Implemented support for image.registry option |
| 0.1.4 | 8.0.31 | Upgraded MySQL to 8.0.31 |
| 0.1.5 | 8.0.31 | Added support for init container resources (thx @Footur) |
| 0.1.6 | 8.0.32 | Upgraded MySQL to 8.0.32 |
| 0.1.7 | 8.0.32 | Implemented alternative distribution with `Deployment` template |
| 0.1.8 | 8.0.32 | Updated default security context |
| 0.1.9 | 8.0.33 | Upgraded MySQL to 8.0.33 |
| 0.1.10 | 8.0.34 | Upgraded MySQL to 8.0.34 |
| 0.1.11 | 8.0.35 | Upgraded MySQL to 8.0.35 |
| 0.2.0 | 8.1.0 | Upgraded MySQL to 8.1.0 |
| 0.3.0 | 8.2.0 | Upgraded MySQL to 8.2.0 |
| 1.0.0 | 8.0.35 | Bumped to stable major chart version - Allows usage of existing secret references and network policies |
| 1.0.1 | 8.0.36 | Upgraded MySQL to 8.0.36 |
| 1.1.0 | 8.2.0 | Bumped to stable major chart version - Allows usage of existing secret references and network policies |
| 1.1.1 | 8.2.0 | Added support for network policies and additional labels and annotations |
| 1.2.0 | 8.3.0 | Upgraded MySQL to 8.3.0 |
| 2.0.0 | 8.0.36 (LTS) | Final version with configuration secret, extra config and extra volume support |
| 2.0.1 | 8.0.36 (LTS) | Updated README |
| 2.0.2 | 8.0.37 (LTS) | Updated README |
| 2.0.3 | 8.0.39 (LTS) | Upgraded MySQL to 8.0.39 |
| 2.0.4 | 8.0.40 (LTS) | Upgraded MySQL to 8.0.40 |
| 2.0.5 | 8.0.41 (LTS) | Upgraded MySQL to 8.0.41 |
| 2.0.6 | 8.0.42 (LTS) | Upgraded MySQL to 8.0.42 |
| 2.0.7 | 8.0.43 (LTS) | Upgraded MySQL to 8.0.43 |
| 2.0.8 | 8.0.44 (LTS) | Upgraded MySQL to 8.0.44 |
| 2.0.9 | 8.0.45 (LTS) | Upgraded MySQL to 8.0.45 |
| 3.0.0 | 8.4.2 (LTS) | Upgraded MySQL to 8.4.2 |
| 3.0.1 | 8.4.3 (LTS) | Upgraded MySQL to 8.4.3 |
| 3.0.2 | 8.4.4 (LTS) | Upgraded MySQL to 8.4.4 |
| 3.0.3 | 8.4.5 (LTS) | Upgraded MySQL to 8.4.5 |
| 3.0.4 | 8.4.6 (LTS) | Upgraded MySQL to 8.4.6 |
| 3.0.5 | 8.4.6 (LTS) | Added support for loadBalancerSourceRanges |
| 3.0.6 | 8.4.6 (LTS) | Added priorityClassName - thx @JimCronqvist |
| 3.0.7 | 8.4.7 (LTS) | Upgraded MySQL to 8.4.7 |
| 3.0.8 | 8.4.7 (LTS) | Added support for persistentVolumeClaimRetentionPolicy |
| 3.0.9 | 8.4.8 (LTS) | Upgraded MySQL to 8.4.8 |
| 3.0.10 | 8.4.9 (LTS) | Upgraded MySQL to 8.4.9 |
| 3.1.0 | 8.7.0 (LTS) | Upgraded MySQL to 9.7.0 |
| | | |
